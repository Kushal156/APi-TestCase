package com.commentRest.commentrest.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.commentRest.commentrest.entities.Comments;

@Service
public class CommentSericeImpl implements CommentService {

	List<Comments> list;
	
	public CommentSericeImpl() {
		
		list = new ArrayList<>();
		list.add(new Comments(12,"kushal","hello","15-03-2024"));
		list.add(new Comments(13,"abhishek","new world","11-03-2023"));
		list.add(new Comments(14,"shiva","this is hard","13-06-2024"));
		list.add(new Comments(15,"anup","typing error","19-09-2024"));
		
	}
	
	@Override
	public List<Comments> getComments() {
		// TODO Auto-generated method stub
		return list;
	}
	
	@Override
	public Comments getComment(long commentid){
		Comments c = null;
		for(Comments comment:list)
		{
			if(comment.getId()==commentid)
			{
				c = comment;
				break;
			}
		}
		return c;
	}

	@Override
	public Comments addComment(Comments comment) {
		list.add(comment);
		return comment;
	}


}
