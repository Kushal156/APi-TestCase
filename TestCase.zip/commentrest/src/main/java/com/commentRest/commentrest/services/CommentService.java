package com.commentRest.commentrest.services;

import java.util.List;

import com.commentRest.commentrest.entities.Comments;

public interface CommentService {
	
	public List<Comments> getComments();
	
	
	public Comments addComment(Comments comment);

	public Comments getComment(long commentid);

}
