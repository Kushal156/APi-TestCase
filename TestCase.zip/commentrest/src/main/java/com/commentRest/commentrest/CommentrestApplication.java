package com.commentRest.commentrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommentrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommentrestApplication.class, args);
	}

}
