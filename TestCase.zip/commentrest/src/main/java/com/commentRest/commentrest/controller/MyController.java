package com.commentRest.commentrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commentRest.commentrest.entities.Comments;
import com.commentRest.commentrest.services.CommentService;

@RestController
public class MyController {

	@Autowired
	private CommentService commentsService;
	
	@GetMapping("/home")
	public String Home() {
	
		return "this is comments page";
	}
	
	//get all comments
	
	@GetMapping("/comments")
	public List<Comments> getComments()
	{
		return this.commentsService.getComments();
	}
	
	// get specific comments 
	@GetMapping("/comments/{commentid}")
	public Comments getComment(@PathVariable String commentid )
	{
		return this.commentsService.getComment(Long.parseLong(commentid));
	}
	
	// adding new comments
	@PostMapping("/comments")
	public Comments addComments(@RequestBody Comments comment) 
	{
		return this.commentsService.addComment(comment);
	}
}
	
