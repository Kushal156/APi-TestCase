package com.commentRest.commentrest.entities;

public class Comments {

	private long id;
	private String name;
	private String text;
	private String date;
	@Override
	public String toString() {
		return "Comments [id=" + id + ", name=" + name + ", text=" + text + ", date=" + date + "]";
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Comments() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Comments(long id, String name, String text, String date) {
		super();
		this.id = id;
		this.name = name;
		this.text = text;
		this.date = date;
	}
}
