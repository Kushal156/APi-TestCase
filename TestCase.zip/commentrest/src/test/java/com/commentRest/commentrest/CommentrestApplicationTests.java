package com.commentRest.commentrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommentrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
